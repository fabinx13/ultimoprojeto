<?php
// admin/db_connect.php

$servername = "localhost";
$username = "luipit9_olp"; // seu usuário
$password = "kkshi1234"; // sua senha
$dbname = "luipit9_olp"; // nome do banco de dados


// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>